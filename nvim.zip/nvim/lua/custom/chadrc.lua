---@type ChadrcConfig 
 local M = {}
 M.ui = {theme = 'nord'}
 M.plugins = "custom.plugins"
 return M
