local plugins = {
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        "pyright",
        "clangd",
      },
    },
  },
  {
    "neovim/nvim-lspconfig",
    config = function ()
      require("configs.lspconfig")
      require("configs.lspconfig")
    end,
  },
}
return plugins
